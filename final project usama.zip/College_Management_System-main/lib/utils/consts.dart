// TODO Implement this library.
import 'package:flutter/material.dart';

final korange= const Color(0xFFFF9933);
final korangelite = const Color(0xFFFFBE83);
final kwhite = const Color(0xFFFFFFFF);
final kblack = const Color(0xFF000000);
final kgreyDark =  Colors.grey.shade700;
final kgreyFill =  Colors.grey.shade100;
